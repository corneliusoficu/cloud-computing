var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var dogSchema = new Schema({
    breed: String,
    name: String,
    color: String,
    weight: Number,
    created_at: Date,
    updated_at: Date
});

var Dog = mongoose.model('Dog', dogSchema);

module.exports = Dog;