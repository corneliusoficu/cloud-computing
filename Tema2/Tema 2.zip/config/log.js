var logger = require('winston');
module.exports = logger;